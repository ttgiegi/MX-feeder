#include "code.h"
#include "config.h"
#include  "ring.h"

// ȥ���ַ����еĿո񣬲����ӳ�������
void remove_spaces(char *str) {
	  int len,i, j = 0;
    if (str == NULL) {
        return;
    }
    len = strlen(str);
    
    for (i = 0; i < len; i++) {
        if (str[i] != ' ') {
            str[j++] = str[i];
        }
    }
    str[j] = '\0';
}


// ���ַ���ת��Ϊ��д
void to_uppercase(char *str) {
	u8 i;
    for (i=0; str[i] != '\0'; i++) {
        str[i] = (char)toupper((unsigned char)str[i]);
    }
}

// ����ָ����浽�ṹ��
void parse_command(char *command, CommandInfo *info) {
    unsigned char i;
    info->is_valid = 0;
    info->letter = '\0';
    strcpy(info->prefix, "");
    strcpy(info->number, "");
    strcpy(info->value, "");

    remove_spaces(command);
    to_uppercase(command);

    // ��һ��ָ�� SxxNxxx
    if (strlen(command) >= 7 && command[0] == 'S' && command[3] == 'N') {
        // �����ĸ S ������λ��Ϊ 2
        if (strlen(command + 1) < 2 || strlen(command + 4) < 3) {
            return;
        }
        for (i = 1; i < 3; i++) {
            if (!isdigit(command[i])) {
                return;
            }
        }
        for (i = 4; i < 7; i++) {
            if (!isdigit(command[i])) {
                return;
            }
        }
        info->is_valid = 1;
        info->letter = 'S';
        strncpy(info->prefix, command + 1, 2);
        info->prefix[2] = '\0';
        strncpy(info->number, command + 4, 3);
        info->number[3] = '\0';
				
    } 
    // �ڶ���ָ�� MxxxNxxxFxx
    else if (strlen(command) >= 11 && command[0] == 'M' && command[4] == 'N' && command[8] == 'F') {
        // �����ĸ M ������λ��Ϊ 3��N ������λ��Ϊ 3��F ������λ��Ϊ 2
        if (strlen(command + 1) < 3 || strlen(command + 5) < 3 || strlen(command + 9) < 2) {
            return;
        }
        for (i = 1; i < 4; i++) {
            if (!isdigit(command[i])) {
                return;
            }
        }
        for (i = 5; i < 8; i++) {
            if (!isdigit(command[i])) {
                return;
            }
        }
        for (i = 9; i < 11; i++) {
            if (!isdigit(command[i])) {
                return;
            }
        }
        info->is_valid = 1;
        info->letter = 'M';
        strncpy(info->prefix, command + 1, 3);
        info->prefix[3] = '\0';
        strncpy(info->number, command + 5, 3);
        info->number[3] = '\0';
        strncpy(info->value, command + 9, 2);
        info->value[2] = '\0';
			
    }
}



// �������յ��ĵ�������
void process_single_data(CommandInfo *info) {
    char command[32];
    int index = 0;
    unsigned char dat;

    while (RingBuffer_Read(&uart4_rx_buffer, &dat)) {
        delay_ms(1);
        if (dat == '\n') {
            if (index > 0) {
                command[index] = '\0';
                parse_command(command, info);

                if (info->is_valid) {
                    if (info->letter == 'S') {
											printf("Valid: Type: %c, command:%s, ID:%s\n", info->letter, info->prefix, info->number);
                    } else if (info->letter == 'M') {
											printf("Valid: Type: %c, command:%s, ID:%s, P:%s\n", info->letter, info->prefix, info->number, info->value);
                    }
                } else {
                    printf("Invalid: %s\n", command);
                }

                index = 0;
            }
        } else {
            command[index++] = dat;
            if (index >= sizeof(command) - 1) {
                index = 0;
            }
        }
    }
}