#ifndef	__TAPE_H
#define	__TAPE_H

#include	"config.h"
#include	"delay.h"
#include	"mcu.h"

#define Per_Pulse_Distance 2 //������������϶֮��ĵļ������

extern int Reset_Flag,Reset_Timer,Load_Flag,In_Position_A;
extern int Tick_Flag,Tick;
void Position_Reset(void);
void Tape_push_multitimes(u8 mm);
void Tape_Back_multitimes(u8 mm);
void Peel_Brake(void);
void Tape_Brake(void);
void Load_Mode(void);

enum Event 
{
	None,
	Mid,
	Up,
	Down,
	Decode,
	ID_Ack,
  Set_ID,
	Forward,
  Back,
	Search,
	Reset_Error,
	Push_error,
	Load,
};
extern enum Event;

extern char mEvent;
extern char kEvent;
extern unsigned int Push_Tick;
extern bit abnormal;




#endif